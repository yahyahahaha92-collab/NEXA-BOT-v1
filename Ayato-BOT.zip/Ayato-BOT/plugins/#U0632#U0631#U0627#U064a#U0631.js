// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  🔘 زراير / تواصل — Contact Card Style
//  𝘼𝙮𝙖𝙩𝙤
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import { readFileSync } from 'fs'

let handler = async (m, { conn }) => {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }) } catch {}
    }
    await react('⏳')

    const botName  = global.botName || '𝘼𝙮𝙖𝙩𝙤'
    const botDev   = global.botDev  || '꧁リヴァイ꧂ & عبد الله'
    const devs = [
        { name: global.botDev1 || '꧁リヴァイ꧂', num: (global.owner?.[0] || global.devNumber  || '').replace(/[^0-9]/g, '') },
        { name: global.botDev2 || 'عبد الله',    num: (global.owner?.[1] || global.devNumber2 || '').replace(/[^0-9]/g, '') }
    ]
    const chLink   = global.links?.channel || ''
    const grpLink  = global.links?.group   || ''
    const suppLink = global.links?.support || ''
    const thumb    = global.images?.owner

    const makeVcard = (d) => [
        `BEGIN:VCARD`,
        `VERSION:3.0`,
        `FN:${d.name}`,
        `ORG:${botName}`,
        `TITLE:مطور ${botName}`,
        `TEL;type=CELL;waid=${d.num}:+${d.num}`,
        `X-WA-BIZ-NAME:${botName}`,
        `X-WA-BIZ-DESCRIPTION:${botName} — بوت واتساب متكامل`,
        `END:VCARD`
    ].join('\n')

    const qkontak = {
        key: { fromMe: false, participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" },
        message: { contactMessage: { displayName: devs[0].name, vcard: makeVcard(devs[0]) } }
    }

    const text = [
        `╔═══「 🤖 ${botName} 」═══╗`,
        `│`,
        `│ 👑 المطور اللول: ${devs[0].name}`,
        `│ 📞 +${devs[0].num}`,
        `│ 💬 https://wa.me/${devs[0].num}`,
        `│`,
        `│ 👑 المطور التاني: ${devs[1].name}`,
        `│ 📞 +${devs[1].num}`,
        `│ 💬 https://wa.me/${devs[1].num}`,
        `│`,
        chLink   ? `│ 📢 القناة: ${chLink}`   : '',
        grpLink  ? `│ 👥 الجروب: ${grpLink}`  : '',
        suppLink ? `│ 🛠️ الدعم: ${suppLink}`  : '',
        `│`,
        `╚══════════════════════╝`
    ].filter(Boolean).join('\n')

    try {
        await conn.sendMessage(m.chat, {
            contacts: { displayName: botDev, contacts: devs.map(d => ({ displayName: d.name, vcard: makeVcard(d) })) },
            contextInfo: {
                externalAdReply: {
                    title: botName,
                    body: `by ${botDev}`,
                    ...(/^https?:/.test(thumb || '') ? { thumbnailUrl: thumb } : { thumbnail: (() => { try { return readFileSync(thumb) } catch { return undefined } })() }),
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: qkontak })

        // رسالة الروابط بعدها
        await conn.sendMessage(m.chat, { text }, { quoted: m })
        await react('✅')
    } catch (e) {
        console.error('[buttons]', e.message)
        await react('❌')
        m.reply(text)
    }
}

handler.help    = ['زراير']
handler.tags    = ['main']
handler.command = /^(زراير|buttons|تواصل|contact)$/i

export default handler