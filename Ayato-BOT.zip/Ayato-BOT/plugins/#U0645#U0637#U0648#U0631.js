
import fetch from 'node-fetch'
import { readFileSync } from 'fs'

let handler = async (m, { conn }) => {
    const react = async (e) => {
        try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }) } catch {}
    }
    await react('⏳')

    const botName  = global.botName || '𝘼𝙮𝙖𝙩𝙤'
    const botDev   = global.botDev  || '꧁リヴァイ꧂ & عبد الله'
    const devs = [
        { name: global.botDev1 || '꧁リヴァイ꧂', num: (global.owner?.[0] || global.devNumber  || '').replace(/[^0-9]/g, '') },
        { name: global.botDev2 || 'عبد الله',    num: (global.owner?.[1] || global.devNumber2 || '').replace(/[^0-9]/g, '') }
    ]
    let thumb = null
    try { thumb = readFileSync(global.images?.bridge) } catch {}

    const makeVcard = (d) => [
        `BEGIN:VCARD`,
        `VERSION:3.0`,
        `FN:${d.name}`,
        `ORG:${botName}`,
        `TITLE:مطور ${botName}`,
        `TEL;type=CELL;waid=${d.num}:+${d.num}`,
        `X-WA-BIZ-NAME:${botName}`,
        `X-WA-BIZ-DESCRIPTION:${botName} — بوت واتساب متكامل`,
        `END:VCARD`
    ].join('\n')

    const qkontak = {
        key: { fromMe: false, participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" },
        message: { contactMessage: { displayName: devs[0].name, vcard: makeVcard(devs[0]) } }
    }

    try {
        await conn.sendMessage(m.chat, {
            contacts: { displayName: botDev, contacts: devs.map(d => ({ displayName: d.name, vcard: makeVcard(d) })) },
            contextInfo: {
                externalAdReply: {
                    title: ` ${botDev}`,
                    body: `مطور ${botName}`,
                    thumbnailUrl: thumb,
                    thumbnail: thumb,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: qkontak })
        await react('✅')
    } catch (e) {
        console.error('[owner]', e.message)
        await react('❌')
        m.reply(` *المطور اللول:* ${devs[0].name}\n +${devs[0].num}\n\n *المطور التاني:* ${devs[1].name}\n +${devs[1].num}`)
    }
}

handler.help    = ['مطور']
handler.tags    = ['main']
handler.command = /^(مطور|owner|creator|المطور|مطوري|مطورك)$/i

export default handler