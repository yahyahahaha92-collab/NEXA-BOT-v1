import path from 'path'
import { fileURLToPath } from 'url'

const media = (f) => path.join(path.dirname(fileURLToPath(import.meta.url)), 'media', f)


const config = {

    botName:    "𝘼𝙮𝙖𝙩𝙤",
    botTag:     "@𝘼𝙮𝙖𝙩𝙤",
    botVersion: "2.0.0",
    botDev1:    "꧁リヴァイ꧂",
    botDev2:    "عبد الله",
    botDev:     "꧁リヴァイ꧂ & عبد الله",
    devNumber:  "212620847586",
    devNumber2: "212648469854",

    sessions:   "sessions",
    botNumber:  "", // رقم البوت هنا ضروري 


    owner: [
        "212620847586", // المطور اللول
        "212648469854", // المطور التاني
    ],

    ownerLid: [],
    prems:    [],
    premsLid: [],

    prefix: /^[°•π÷×¶∆£¢€¥®™✓=|~!?#%^&.]/,

    
    ch: {
        main:    "120363428637387322@newsletter",
        second:  "120363428637387322@newsletter", // خلهم مش هيفيدوك🐦
    },

   
    

    theme: {
        border:    "🪻",
        icon:      "✦",
        separator: "~*『✦▬▬▬✦┇• 🪻 •┇✦▬▬▬✦』*~",
        header:    (title) => `╔═══「 🪻 ${title} 🪻 」═══╗`,
        subHeader: (title) => `┌─「 ✦ ${title} 」`,
        tail:      `╚══════════════════════╝`,
        subTail:   `└──────────────────────`,
        footer:    `〔 𝘼𝙮𝙖𝙩𝙤 〕`,
        row:       (key, val) => `│ ✦ ${key}: 〘${val}〙`,
        zarfLine:  `~*『✦▬▬▬✦┇• 🪻 •┇✦▬▬▬✦』*~`,
    },

    links: {
        channel: "https://whatsapp.com/channel/0029VbDnEPG1iUxfnegKky46",
        group:   "https://chat.whatsapp.com/IqEK2Q8fPZTHkB7MyJzIPN?s=cl&p=a&iam=2",
        support: "https://chat.whatsapp.com/IqEK2Q8fPZTHkB7MyJzIPN?s=cl&p=a&iam=2",
        github:  "https://github.com/Loydsumer/baileys-speed",
        dev:     "https://wa.me/212620847586",
        dev2:    "https://wa.me/212648469854",
    },

    images: {
        menu:       media('menu.jpg'),          // بانر Ayato Bot Commands
        owner:      media('ayato-bridge.jpg'),
        group:      media('ayato-garden.jpg'),
        economy:    media('ayato-bridge.jpg'),
        games:      media('ayato-garden.jpg'),
        tools:      media('ayato-bridge.jpg'),
        info:       media('ayato-garden.jpg'),
        downloader: media('ayato-bridge.jpg'),
        ai:         media('menu.jpg'),
        garden:     media('ayato-garden.jpg'),
        bridge:     media('ayato-bridge.jpg'),
        thumb:      media('thumb.jpg'),
    },

    opts: {
        queque:    false,
        restrict:  false,
        noprint:   false,
        autoread:  true,
        autoReact: true,
    },
}


global.botName    = config.botName
global.botTag     = config.botTag
global.botVersion = config.botVersion
global.botDev     = config.botDev
global.botDev1    = config.botDev1
global.botDev2    = config.botDev2
global.devNumber  = config.devNumber
global.devNumber2 = config.devNumber2
global.sessions   = config.sessions
global.botNumber  = config.botNumber
global.owner      = config.owner
global.ownerLid   = config.ownerLid
global.prems      = config.prems
global.premsLid   = config.premsLid
global.prefix     = config.prefix
global.ch         = config.ch
global.zarf       = config.zarf
global.theme      = config.theme
global.links      = config.links
global.images     = config.images
global.zarf_settings = config.zarf_settings

global.opts = { ...config.opts, ...(global.opts || {}) }

export default config
